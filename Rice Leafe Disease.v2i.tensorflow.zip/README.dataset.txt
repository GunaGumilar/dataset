# Rice Leafe Disease > 2024-11-17 3:43pm
https://universe.roboflow.com/corrosion-l4cqs/rice-leafe-disease

Provided by a Roboflow user
License: CC BY 4.0

